
# Trabalho 1: Coleta, Preparação e Análise de Dados

### Integrantes:
- Giovane Bianchi Milani (21102209)
- Vinícius Boff (21103109)
- André Rodrigues (20280010)

### Como rodar:

#### Instale as dependências:

```bash
pip install -r requirements.txt
```

#### Rodar tarefa 1:
```shell
python tarefa1.py
```

#### Rodar tarefa 2:
```shell
python tarefa2.py
```